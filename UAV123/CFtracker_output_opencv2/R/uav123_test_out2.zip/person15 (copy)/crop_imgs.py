import cv2
import os

img_fold = "/media/dtu-project2/2GB_HDD/object_tracker/UAV123/CFtracker_output_opencv2/person16 (copy)/csrdcf_rel"

img_list  = os.listdir(img_fold)
img_list.sort()

for img in img_list:
    path = os.path.join(img_fold, img)
    image = cv2.imread(path)
    (h, w, c) = image.shape
    image = image[h//2-50-50:h//2+50+50, w//2-50-50:w//2+50+50]
    cv2.imwrite(path, image)
    print(image.shape)
    